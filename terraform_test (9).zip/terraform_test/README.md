# Technical exercise 

Here you have some terraform, which does not work! 
Please fix it and send us your fixed version.
Feel free to add useful functionality where you feel its appropriate and please list out any questions or assumptions you make.